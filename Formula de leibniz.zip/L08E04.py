## Lista 08, Exercicio 04
## Aluno: André Augusto Superbi Gomes
## RA: 11202111784

s = 1
x = 0
n = int(input('Digite n: '))
for c in range(0,n*2 - 2,2):
    if x % 2 == 0:
        s -= 1/(c+3)
    else:
        s += 1/(c+3)
    x+=1
pi = 4*s
print(f'{pi:.4f}')